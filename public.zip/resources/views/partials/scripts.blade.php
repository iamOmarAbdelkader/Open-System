
<!-- jQuery 3 -->
<script src="{{asset('adminlte/bower_components/jquery/dist/jquery.min.js')}}"></script>
<!-- Bootstrap 3.3.7 -->
<script src="{{asset('adminlte/bower_components/bootstrap/dist/js/bootstrap.min.js')}}"></script>
<!-- SlimScroll -->
<script src="{{asset('adminlte/bower_components/jquery-slimscroll/jquery.slimscroll.min.js')}}"></script>
<!-- FastClick -->
<script src="{{asset('adminlte/bower_components/fastclick/lib/fastclick.js')}}"></script>
<!-- AdminLTE App -->
<script src="{{asset('adminlte/dist/js/adminlte.js')}}"></script>
<!-- jquery validate -->
<script src="{{asset('js/jquery.validate.min.js')}}"></script>
<!-- jquery validate aditional -->
<script src="{{asset('js/additional-methods.min.js')}}"></script>
<!-- jquery validate localization -->
<script src="{{asset('js/messages_ar.js')}}"></script>
    	<!-- Data Tables -->
	<script src="{{asset('plugins/datatables/media/js/jquery.dataTables.min.js')}}"></script>

	<script src="{{asset('plugins/datatables/media/js/dataTables.bootstrap.min.js')}}"></script>

	<script src="{{asset('plugins/datatables/extensions/Responsive/js/dataTables.responsive.min.js')}}"></script>

	<script src="{{asset('plugins/datatables/extensions/Responsive/js/responsive.bootstrap.min.js')}}"></script>

	<script src="{{asset('plugins/datatables/new/buttons.html5.min.js')}}"></script>

	<script src="{{asset('plugins/datatables/new/buttons.print.min.js')}}"></script>    

	<script src="{{asset('plugins/datatables/new/dataTables.buttons.min.js')}}"></script>

    

	<script src="{{asset('plugins/datatables/new/buttons.bootstrap.min.js')}}"></script>

    

	<script src="{{asset('plugins/datatables/new/szip.min.js')}}"></script>

	<script src="{{asset('plugins/datatables/new/vfs_fonts.js')}}"></script>

	<script src="{{asset('plugins/datatables/new/buttons.colVis.min.js')}}"></script>
{{--  bootstrap datepicker   --}}
<script src="{{asset('adminlte\bower_components\bootstrap-datepicker\dist\js\bootstrap-datepicker.js')}}"></script>
<script src="{{asset('js\bootstrap-datepicker.ar.js')}}" charset="UTF-8"></script>


<script src="{{asset('js/select2.min.js')}}"></script>
<script src="{{asset('js/file-upload.js')}}"></script>
<script src="{{asset('js/iziToast.min.js')}}"></script>
<script src="{{asset('js/jquery.fancybox.js')}}"></script>

<script src="{{asset('js/jquery-confirm.min.js')}}"></script>

<script src="{{asset('js/jstree.js')}}"></script>


<!-- Presales -->
<script src="{{asset('js/app.js')}}"></script>

