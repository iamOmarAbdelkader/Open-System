@foreach($permissions as $permission)

<span class="label  label-info">{{ $permission->display_name }}</span>

@endforeach