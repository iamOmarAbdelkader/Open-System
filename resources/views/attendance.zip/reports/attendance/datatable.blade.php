@if($status)
<i class="fa fa-check"></i>
@else
<i class="fa fa-close"></i>
@endif